$port = 25
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $port)
$listener.Start()

$startTime = Get-Date -Format "HH:mm:ss"
Write-Host "[$startTime] SMTP Sink Active on port $port..." -ForegroundColor Cyan
Write-Host "Press Ctrl+C to stop the listener and release the port." -ForegroundColor Yellow

try {
    while ($true) {
        if ($listener.Pending()) {
            $client = $listener.AcceptTcpClient()
            $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "`n[$timestamp] [+] Connection received from $($client.Client.RemoteEndPoint)" -ForegroundColor Green
            
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $writer = New-Object System.IO.StreamWriter($stream)
            $writer.AutoFlush = $true 

            $writer.WriteLine("220 localhost ESMTP Sink Ready")
            
            while ($client.Connected) {
                $line = $reader.ReadLine()
                if ($null -eq $line) { break }
                
                $cmdTime = Get-Date -Format "HH:mm:ss.fff"
                Write-Host "  [$cmdTime] >> $line" -ForegroundColor Gray
                
                switch -regex ($line) {
                    "^(HELO|EHLO)" { 
                        $writer.WriteLine("250-localhost Hello")
                        $writer.WriteLine("250 OK") 
                    }
                    "^MAIL FROM"   { $writer.WriteLine("250 OK") }
                    "^RCPT TO"     { $writer.WriteLine("250 OK") }
                    "^DATA"        { 
                        $writer.WriteLine("354 Start mail input; end with <CR><LF>.<CR><LF>")
                        while (($dataLine = $reader.ReadLine()) -ne ".") { } 
                        $writer.WriteLine("250 OK")
                    }
                    "^QUIT" { 
                        $writer.WriteLine("221 Bye")
                        $client.Close() 
                    }
                    default { 
                        $writer.WriteLine("250 OK") 
                    }
                }
            }
            $endTime = Get-Date -Format "HH:mm:ss"
            Write-Host "[$endTime] [-] Transaction complete / Connection closed." -ForegroundColor Yellow
        }
        else {
            # Heartbeat to show script is still alive in the console
            Write-Host "." -NoNewline
            Start-Sleep -Milliseconds 500
        }
    }
}
finally {
    $listener.Stop()
    $stopTime = Get-Date -Format "HH:mm:ss"
    Write-Host "`n[$stopTime] [!] Listener stopped and port 25 released." -ForegroundColor Red
}