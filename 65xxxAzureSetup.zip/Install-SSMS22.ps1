# Requires -RunAsAdministrator

$WorkingDir = "C:\Temp"
$installDir  = "C:\Classfiles"
$destination = "$installDir\vs_SSMS.exe"
$logFile     = "$installDir\SSMS22_Install.log"
$source      = "https://aka.ms/ssms/22/release/vs_SSMS.exe"

# Ensure destination directory exists
if (-not (Test-Path $installDir)) {
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null
}
# Move to working directory
Set-Location -Path $WorkDir

# Enforce TLS 1.2 for the download (good practice on Server 2025)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Write-Host "Downloading SSMS 22 bootstrapper..."
Invoke-WebRequest -Uri $source -OutFile $destination -UseBasicParsing

Write-Host "Starting SSMS 22 silent installation..."
$installArgs = "--passive --includeRecommended --norestart --wait"

$process = Start-Process `
    -FilePath $destination `
    -ArgumentList $installArgs `
    -Wait `
    -PassThru

# SAFETY CHECK: Wait for the underlying VS Installer engine to finish
# The bootstrapper often spawns 'vs_setup.exe' or 'setup.exe'
Write-Host "Waiting for background installer processes to clear..."
$installerProcesses = @("vs_setup", "setup", "vs_installer")

do {
    $running = Get-Process -Name $installerProcesses -ErrorAction SilentlyContinue
    if ($running) {
        Start-Sleep -Seconds 5
    }
} while ($running)

Write-Host "Installation complete."

# Disable certificate revocation checks
reg add "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\WinTrust\Trust Providers\Software Publishing" /v State /t REG_DWORD /d 0x23c00 /f

# Run this to optimize the SSMS 22 binaries
$ngenPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\ngen.exe"
$ssmsPath = "C:\Program Files\Microsoft SQL Server Management Studio 22\Release\Common7\IDE\Ssms.exe"

Start-Process -FilePath $ngenPath -ArgumentList "install `"$ssmsPath`"" -Wait





