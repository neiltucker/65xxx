# Install-SQLServerSSLCert.ps1
# Generates a self-signed SSL certificate for SQL Server 2025,
# installs it into the local machine certificate store,
# configures SQL Server to use it, and restarts the service.
#
# Run as Administrator on the SQL Server machine.
# After running this script, bcp and all ODBC Driver 18 connections
# will work without SSL errors.
#
# Usage:
#   Set-ExecutionPolicy Bypass -Scope Process -Force
#   .\Install-SQLServerSSLCert.ps1
#
# To run silently from a sim or deployment script:
#   powershell.exe -ExecutionPolicy Bypass -NonInteractive -File Install-SQLServerSSLCert.ps1

#Requires -RunAsAdministrator

$ErrorActionPreference = "Stop"

# ── Configuration ────────────────────────────────────────────────────────────
$SqlInstance    = "MSSQLSERVER"          # Change to MSSQL$INSTANCENAME for named instances
$SqlServiceAcct = "NT Service\MSSQLSERVER"  # Change for named instances
$CertSubject    = "CN=$env:COMPUTERNAME"
$CertStore      = "Cert:\LocalMachine\My"
$CertExpYears   = 5
$RegPath        = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL17.MSSQLSERVER\MSSQLServer\SuperSocketNetLib"
# ─────────────────────────────────────────────────────────────────────────────

function Write-Status {
    param([string]$Msg, [string]$Color = "Cyan")
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] $Msg" -ForegroundColor $Color
}

Write-Status "=== SQL Server SSL Certificate Installer ===" "White"
Write-Status "Computer : $env:COMPUTERNAME"
Write-Status "Instance : $SqlInstance"

# ── Step 1: Check if cert already exists and is valid ────────────────────────
Write-Status "Step 1: Checking for existing SQL Server SSL certificate..."
$existing = Get-ChildItem $CertStore |
    Where-Object { $_.Subject -eq $CertSubject -and $_.NotAfter -gt (Get-Date) } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1

if ($existing) {
    Write-Status "Found existing valid cert: $($existing.Thumbprint) (expires $($existing.NotAfter.ToString('yyyy-MM-dd')))" "Yellow"
    Write-Status "Skipping certificate generation -- using existing cert." "Yellow"
    $cert = $existing
} else {
    # ── Step 2: Generate self-signed certificate ──────────────────────────────
    Write-Status "Step 2: Generating self-signed SSL certificate..."
    $cert = New-SelfSignedCertificate `
        -Subject         $CertSubject `
        -DnsName         $env:COMPUTERNAME, "localhost", "127.0.0.1" `
        -CertStoreLocation $CertStore `
        -KeyExportPolicy Exportable `
        -KeySpec         KeyExchange `
        -KeyLength       2048 `
        -HashAlgorithm   SHA256 `
        -NotAfter        (Get-Date).AddYears($CertExpYears) `
        -KeyUsage        DigitalSignature, KeyEncipherment `
        -TextExtension   @("2.5.29.37={text}1.3.6.1.5.5.7.3.1")

    Write-Status "Certificate created: $($cert.Thumbprint)" "Green"
    Write-Status "  Subject  : $($cert.Subject)"
    Write-Status "  Expires  : $($cert.NotAfter.ToString('yyyy-MM-dd'))"
}

# ── Step 3: Add cert to Trusted Root store ───────────────────────────────────
Write-Status "Step 3: Adding certificate to Trusted Root store..."
$rootStore = New-Object System.Security.Cryptography.X509Certificates.X509Store(
    "Root", "LocalMachine")
$rootStore.Open("ReadWrite")
$alreadyTrusted = $rootStore.Certificates | Where-Object { $_.Thumbprint -eq $cert.Thumbprint }
if (-not $alreadyTrusted) {
    $rootStore.Add($cert)
    Write-Status "Certificate added to Trusted Root store." "Green"
} else {
    Write-Status "Certificate already in Trusted Root store." "Yellow"
}
$rootStore.Close()

# ── Step 4: Grant SQL Server service account read access to private key ───────
Write-Status "Step 4: Granting SQL Server service account access to certificate private key..."
$keyPath = "$env:ProgramData\Microsoft\Crypto\RSA\MachineKeys"
$keyFile = Get-ChildItem $keyPath |
    Where-Object { $_.Name -eq (
        [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert) `
        | ForEach-Object { $_.Key.UniqueName }
    )} | Select-Object -First 1

if ($keyFile) {
    $acl = Get-Acl $keyFile.FullName
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
        $SqlServiceAcct, "Read", "Allow")
    $acl.AddAccessRule($rule)
    Set-Acl $keyFile.FullName $acl
    Write-Status "Access granted to: $SqlServiceAcct" "Green"
} else {
    # Fallback: grant access to entire MachineKeys folder for this cert
    Write-Status "Key file not found by path -- using certutil to grant access..." "Yellow"
    $thumbprint = $cert.Thumbprint
    & certutil -repairstore My $thumbprint 2>$null
    # Grant via icacls on the MachineKeys folder
    & icacls $keyPath /grant "${SqlServiceAcct}:(R)" /T /Q 2>$null
    Write-Status "Access granted via icacls." "Green"
}

# ── Step 5: Configure SQL Server to use this certificate ─────────────────────
Write-Status "Step 5: Configuring SQL Server to use certificate (thumbprint: $($cert.Thumbprint))..."

# Try registry path for default instance first, then enumerate
$regPaths = @(
    "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL17.MSSQLSERVER\MSSQLServer\SuperSocketNetLib",
    "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQLServer\SuperSocketNetLib",
    "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQLServer\SuperSocketNetLib"
)

$configured = $false
foreach ($rp in $regPaths) {
    if (Test-Path $rp) {
        Set-ItemProperty -Path $rp -Name "Certificate" -Value $cert.Thumbprint.ToLower()
        Set-ItemProperty -Path $rp -Name "ForceEncryption" -Value 0 -Type DWord
        Write-Status "Registry updated: $rp" "Green"
        $configured = $true
        break
    }
}

if (-not $configured) {
    # Search registry dynamically
    Write-Status "Searching registry for SQL Server instance path..." "Yellow"
    $sqlKeys = Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\" -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match "MSSQL\d+\." }
    foreach ($key in $sqlKeys) {
        $netLibPath = "$($key.PSPath)\MSSQLServer\SuperSocketNetLib"
        if (Test-Path $netLibPath) {
            Set-ItemProperty -Path $netLibPath -Name "Certificate" -Value $cert.Thumbprint.ToLower()
            Set-ItemProperty -Path $netLibPath -Name "ForceEncryption" -Value 0 -Type DWord
            Write-Status "Registry updated: $netLibPath" "Green"
            $configured = $true
        }
    }
}

if (-not $configured) {
    Write-Status "WARNING: Could not find SQL Server registry path. Configure certificate manually via SQL Server Configuration Manager." "Red"
}

# ── Step 6: Restart SQL Server service ───────────────────────────────────────
Write-Status "Step 6: Restarting SQL Server service ($SqlInstance)..."
try {
    Restart-Service -Name $SqlInstance -Force
    Start-Sleep -Seconds 5
    $svc = Get-Service -Name $SqlInstance
    if ($svc.Status -eq "Running") {
        Write-Status "SQL Server restarted successfully." "Green"
    } else {
        Write-Status "SQL Server status: $($svc.Status) -- check Event Log." "Red"
    }
} catch {
    Write-Status "Restart failed: $_" "Red"
    Write-Status "Please restart SQL Server manually via services.msc or SQL Server Configuration Manager." "Yellow"
}

# ── Step 7: Verify bcp works ─────────────────────────────────────────────────
Write-Status "Step 7: Testing bcp connectivity..."
Start-Sleep -Seconds 3
$bcpOut = & bcp "SELECT 1" queryout NUL -T -S localhost -c 2>&1 | Out-String
if ($bcpOut -match "1 rows") {
    Write-Status "bcp test PASSED -- SSL certificate working correctly." "Green"
} else {
    Write-Status "bcp test result: $bcpOut" "Yellow"
    Write-Status "If errors persist, verify certificate in SQL Server Configuration Manager." "Yellow"
}

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Status "" "White"
Write-Status "=== Summary ===" "White"
Write-Status "Certificate thumbprint : $($cert.Thumbprint)" "White"
Write-Status "Certificate subject    : $($cert.Subject)" "White"
Write-Status "Certificate expires    : $($cert.NotAfter.ToString('yyyy-MM-dd'))" "White"
Write-Status "Trusted Root store     : Added" "White"
Write-Status "SQL Server configured  : $(if ($configured) { 'Yes' } else { 'Manual step required' })" "White"
Write-Status "" "White"
Write-Status "Script complete. bcp and ODBC Driver 18 connections should now work without SSL errors." "Green"
