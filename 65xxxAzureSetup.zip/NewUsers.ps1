@"
FirstName,LastName,JobTitle,Department,UsageLocation
John,Doe,Cloud Administrator,IT,US
...
"@ | Out-File "C:\Labs\NewUsers.csv" -Encoding UTF8