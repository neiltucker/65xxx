# 1. Generate Domain Names based on Computer Name
$computerName = $env:COMPUTERNAME
$prefix = if ($computerName.Length -ge 5) { $computerName.Substring(0,5) } else { $computerName }
$domainNetbiosName = ($prefix + "domain").ToUpper()
$domainFQDN = "$($domainNetbiosName.ToLower()).local"

Write-Host "Configuring Forest: $domainFQDN" -ForegroundColor Cyan

# 2. Set DSRM Password (Change 'P@ssword123!' to a secure one)
$dsrmPassword = ConvertTo-SecureString "Pa$$w0rdPa$$w0rd" -AsPlainText -Force

# 3. Install AD DS Binaries
Write-Host "Installing Active Directory Domain Services Role..."
Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools

# 4. Configure DNS Settings
$alias = (Get-NetAdapter | Where-Object { $_.Status -eq "Up" }).Name
Set-DnsClientServerAddress -InterfaceAlias $alias -ServerAddresses ("127.0.0.1")
Add-DnsServerForwarder -IPAddress "8.8.8.8", "1.1.1.1" -PassThru

# 5. Promote to Domain Controller (Add New Forest)
# Functional Level 10 corresponds to Windows Server 2025
Write-Host "Promoting to Domain Controller... The server will reboot automatically."
Install-ADDSForest `
    -DomainName $domainFQDN `
    -DomainNetbiosName $domainNetbiosName `
    -DomainMode "WinThreshold" `
    -ForestMode "WinThreshold" `
    -InstallDns:$true `
    -SafeModeAdministratorPassword $dsrmPassword `
    -Force:$true `
    -NoRebootOnCompletion:$false

