<#
.SYNOPSIS
    SQL Database Download & Install Manager.
    Downloads .bak files into C:\Classfiles and restores them to a local SQL
    Server. Supports the three Microsoft sample databases:

        1. AdventureWorks2025
        2. AdventureWorksLT2025
        3. WideWorldImporters

.DESCRIPTION
    Fixes the original script's bugs:

      * No WITH MOVE clauses -> RESTORE tried to use the original paths baked
        into the .bak file (e.g. D:\Program Files\Microsoft SQL Server\
        MSSQL13.SQL16\MSSQL\DATA\) which don't exist on most machines.
        FIX: build MOVE clauses from RESTORE FILELISTONLY, pointing every file
             at SQL Server's local default data/log paths.

      * No handling for FILESTREAM / In-Memory OLTP containers, which are
        DIRECTORIES, not files (WideWorldImporters has WWI_InMemory_Data_1).
        FIX: detect file Type='S' and MOVE it to a directory path.

      * Invoke-Sqlcmd -TrustServerCertificate not supported in older versions
        of the SqlServer module.
        FIX: detect the parameter at runtime and only pass it when supported.

      * Parameter named $db collided with the built-in -Debug alias 'db' on
        advanced functions.
        FIX: parameter renamed to $Database.

.PARAMETER ServerInstance
    SQL Server instance to restore to. Default: 'localhost'.

.PARAMETER BasePath
    Working folder for the .bak downloads. Default: 'C:\Classfiles'.

.PARAMETER DbChoice
    Skip the database menu. 1..3 picks one DB, 4 = ALL.

.PARAMETER ActionChoice
    Skip the action menu. 1 = Download Only, 2 = Install Only, 3 = Both.

.EXAMPLE
    .\databases.ps1

.EXAMPLE
    .\databases.ps1 -DbChoice 4 -ActionChoice 3

.EXAMPLE
    .\databases.ps1 -ServerInstance '.\SQLEXPRESS' -DbChoice 3 -ActionChoice 2

.NOTES
    Run PowerShell as Administrator. The Windows account must have RESTORE
    rights on the SQL Server instance (typically sysadmin).
#>

[CmdletBinding()]
param(
    [string]$ServerInstance = 'localhost',
    [string]$BasePath       = 'C:\Classfiles',
    [ValidateRange(0,4)] [int]$DbChoice     = -1,
    [ValidateRange(1,3)] [int]$ActionChoice = -1
)

# ---------------------------------------------------------------------
# Version marker - if you don't see "v3 (3-DB + TrustCert-safe)" in the
# banner, you're running an old copy of this file.
# ---------------------------------------------------------------------
$ScriptVersion = 'v3 (3-DB + TrustCert-safe)'
Write-Host ("[databases.ps1 {0}] script loaded from: {1}" -f $ScriptVersion, $PSCommandPath) -ForegroundColor DarkGreen

# =====================================================================
# Database catalog (Microsoft public samples only)
# =====================================================================
$Databases = @(
    [pscustomobject]@{ ID=1; Name='AdventureWorks2025';   FileName='AdventureWorks2025.bak';      Url='https://github.com/Microsoft/sql-server-samples/releases/download/adventureworks/AdventureWorks2025.bak' }
    [pscustomobject]@{ ID=2; Name='AdventureWorksLT2025'; FileName='AdventureWorksLT2025.bak';    Url='https://github.com/Microsoft/sql-server-samples/releases/download/adventureworks/AdventureWorksLT2025.bak' }
    [pscustomobject]@{ ID=3; Name='WideWorldImporters';   FileName='WideWorldImporters-Full.bak'; Url='https://github.com/Microsoft/sql-server-samples/releases/download/wide-world-importers-v1.0/WideWorldImporters-Full.bak' }
)

# =====================================================================
# Setup
# =====================================================================
if (-not (Test-Path -Path $BasePath)) {
    New-Item -ItemType Directory -Path $BasePath -Force | Out-Null
    Write-Host "Created directory: $BasePath" -ForegroundColor Green
}

# =====================================================================
# SQL helpers - prefer Invoke-Sqlcmd, fall back to sqlcmd.exe.
# Detect -TrustServerCertificate at runtime: newer SqlServer module
# versions (>=21.1) need it for default-encrypted connections; older
# versions don't have the parameter at all.
# =====================================================================
$script:SqlTooling        = $null   # 'module' | 'exe'
$script:SupportsTrustCert = $false

function Initialize-SqlTooling {
    if ($script:SqlTooling) { return }

    $cmd = Get-Command -Name Invoke-Sqlcmd -ErrorAction SilentlyContinue
    if ($cmd) {
        $script:SqlTooling = 'module'
        $script:SupportsTrustCert = $cmd.Parameters.ContainsKey('TrustServerCertificate')
        $tcMsg = if ($script:SupportsTrustCert) { 'with -TrustServerCertificate support' } else { 'older module - no -TrustServerCertificate (not needed)' }
        Write-Host "[setup] Using Invoke-Sqlcmd ($tcMsg)." -ForegroundColor DarkGray
        return
    }

    if (Get-Command -Name sqlcmd.exe -ErrorAction SilentlyContinue) {
        $script:SqlTooling = 'exe'
        Write-Host "[setup] Using sqlcmd.exe fallback (SqlServer PowerShell module not installed)." -ForegroundColor DarkGray
        return
    }

    throw "Neither 'Invoke-Sqlcmd' (SqlServer module) nor sqlcmd.exe is available. Run: Install-Module SqlServer -Scope CurrentUser"
}

function Invoke-Sql {
    param(
        [Parameter(Mandatory)] [string]$Server,
        [Parameter(Mandatory)] [string]$Query,
        [int]$QueryTimeout = 0
    )
    Initialize-SqlTooling

    if ($script:SqlTooling -eq 'module') {
        $splat = @{
            ServerInstance = $Server
            Query          = $Query
            QueryTimeout   = $QueryTimeout
            ErrorAction    = 'Stop'
        }
        if ($script:SupportsTrustCert) { $splat.TrustServerCertificate = $true }
        return Invoke-Sqlcmd @splat
    }

    # sqlcmd.exe fallback
    $tmp = [IO.Path]::Combine([IO.Path]::GetTempPath(), [IO.Path]::GetRandomFileName() + '.sql')
    Set-Content -LiteralPath $tmp -Value $Query -Encoding ASCII
    try {
        # Try with -C (trust cert) first; retry without it if the binary is too old to know -C.
        $output = & sqlcmd.exe -S $Server -E -C -b -h -1 -W -t $QueryTimeout -i $tmp 2>&1
        if ($LASTEXITCODE -ne 0) {
            $output = & sqlcmd.exe -S $Server -E -b -h -1 -W -t $QueryTimeout -i $tmp 2>&1
        }
        if ($LASTEXITCODE -ne 0) {
            throw "sqlcmd failed (exit $LASTEXITCODE):`n$($output -join [Environment]::NewLine)"
        }
        return $output
    } finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}

function Get-SqlDefaultPaths {
    param([Parameter(Mandatory)][string]$Server)

    $q = @"
SELECT
    CAST(ISNULL(SERVERPROPERTY('InstanceDefaultDataPath'),
        (SELECT CAST(value_in_use AS NVARCHAR(512))
         FROM sys.configurations WHERE name = 'DefaultDataPath')) AS NVARCHAR(512)) AS DataPath,
    CAST(ISNULL(SERVERPROPERTY('InstanceDefaultLogPath'),
        (SELECT CAST(value_in_use AS NVARCHAR(512))
         FROM sys.configurations WHERE name = 'DefaultLogPath'))  AS NVARCHAR(512)) AS LogPath;
"@
    $r = Invoke-Sql -Server $Server -Query $q

    $data = ($r.DataPath | Select-Object -First 1)
    $log  = ($r.LogPath  | Select-Object -First 1)

    if ([string]::IsNullOrWhiteSpace($data)) {
        $r2 = Invoke-Sql -Server $Server -Query @"
SELECT TOP 1 LEFT(physical_name, LEN(physical_name) - CHARINDEX('\', REVERSE(physical_name)) + 1) AS MasterDir
FROM sys.master_files WHERE database_id = 1 AND type = 0;
"@
        $data = ($r2.MasterDir | Select-Object -First 1)
    }
    if ([string]::IsNullOrWhiteSpace($log)) { $log = $data }

    if ($data -and $data[-1] -ne '\') { $data = $data + '\' }
    if ($log  -and $log[-1]  -ne '\') { $log  = $log  + '\' }

    return [pscustomobject]@{ DataPath = $data; LogPath = $log }
}

# =====================================================================
# Download
# =====================================================================
function Download-Database {
    param([Parameter(Mandatory)]$Database)

    $Destination = Join-Path -Path $BasePath -ChildPath $Database.FileName

    if (Test-Path -LiteralPath $Destination) {
        $size = (Get-Item -LiteralPath $Destination).Length
        if ($size -gt 0) {
            Write-Host "[$($Database.Name)] Already downloaded ($([math]::Round($size/1MB,1)) MB). Skipping." -ForegroundColor Yellow
            return $true
        }
        Remove-Item -LiteralPath $Destination -Force
    }

    Write-Host "`n[$($Database.Name)] Starting download..." -ForegroundColor Cyan
    Write-Host "    From: $($Database.Url)" -ForegroundColor DarkGray
    Write-Host "    To  : $Destination"     -ForegroundColor DarkGray

    try {
        if (Get-Command -Name Start-BitsTransfer -ErrorAction SilentlyContinue) {
            Start-BitsTransfer -Source $Database.Url -Destination $Destination -ErrorAction Stop
        } else {
            $oldPref = $ProgressPreference
            $ProgressPreference = 'SilentlyContinue'
            try   { Invoke-WebRequest -Uri $Database.Url -OutFile $Destination -UseBasicParsing -ErrorAction Stop }
            finally { $ProgressPreference = $oldPref }
        }
        $size = (Get-Item -LiteralPath $Destination).Length
        Write-Host ("[$($Database.Name)] Download successful: {0:N1} MB" -f ($size / 1MB)) -ForegroundColor Green
        return $true
    } catch {
        if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue }
        Write-Host "[$($Database.Name)] Download failed.`nError: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# =====================================================================
# Restore
# =====================================================================
function Install-Database {
    param([Parameter(Mandatory)]$Database)

    $BackupFile = Join-Path -Path $BasePath -ChildPath $Database.FileName

    if (-not (Test-Path -LiteralPath $BackupFile)) {
        Write-Host "`n[$($Database.Name)] Cannot install. Backup file not found at $BackupFile" -ForegroundColor Yellow
        return
    }

    Write-Host "`n[$($Database.Name)] Starting installation (Restore) to $ServerInstance..." -ForegroundColor Cyan

    try {
        # ---- 1. Read the file list embedded in the .bak ----
        $fileListQ = "RESTORE FILELISTONLY FROM DISK = N'$($BackupFile.Replace("'","''"))';"
        $files = Invoke-Sql -Server $ServerInstance -Query $fileListQ
        if (-not $files) { throw "RESTORE FILELISTONLY returned no rows." }

        # ---- 2. Discover the local server's default data/log paths ----
        $paths = Get-SqlDefaultPaths -Server $ServerInstance
        if (-not $paths.DataPath) {
            throw "Could not determine the SQL Server default data path. Configure InstanceDefaultDataPath in the instance properties."
        }
        Write-Host "    Data path: $($paths.DataPath)" -ForegroundColor DarkGray
        Write-Host "    Log path : $($paths.LogPath)"  -ForegroundColor DarkGray

        # ---- 3. Build one MOVE clause per file, by type ----
        $moves        = New-Object System.Collections.Generic.List[string]
        $dataFileIdx  = 0

        foreach ($f in $files) {
            $logical = "$($f.LogicalName)"
            $typeRaw = "$($f.Type)".Trim().ToUpper()
            $typeDesc = ''
            if ($f.PSObject.Properties.Name -contains 'TypeDesc') {
                $typeDesc = "$($f.TypeDesc)".Trim().ToUpper()
            }

            # Normalize to single character D | L | S | F
            $fileType = switch -Wildcard ($typeRaw) {
                'D' { 'D'; break }
                'L' { 'L'; break }
                'S' { 'S'; break }   # FILESTREAM or memory-optimized container (directory!)
                'F' { 'F'; break }   # Full-text catalog
                default {
                    switch -Wildcard ($typeDesc) {
                        'ROWS*'                 { 'D'; break }
                        'LOG*'                  { 'L'; break }
                        'FILESTREAM*'           { 'S'; break }
                        '*MEMORY*OPTIMIZED*'    { 'S'; break }
                        'FULLTEXT*'             { 'F'; break }
                        default                 { 'D' }
                    }
                }
            }

            switch ($fileType) {
                'L' {
                    $physical = Join-Path $paths.LogPath  ("{0}.ldf" -f $Database.Name)
                }
                'D' {
                    $dataFileIdx++
                    $ext      = if ($dataFileIdx -eq 1) { '.mdf' } else { "_$dataFileIdx.ndf" }
                    $physical = Join-Path $paths.DataPath ("{0}{1}" -f $Database.Name, $ext)
                }
                default {
                    # FILESTREAM / Memory-Optimized container = DIRECTORY, no extension
                    $physical = Join-Path $paths.DataPath ("{0}_{1}" -f $Database.Name, $logical)
                }
            }

            $moves.Add("MOVE N'$($logical.Replace("'","''"))' TO N'$($physical.Replace("'","''"))'")
        }

        $moveClause = $moves -join ",`n     "

        # ---- 4. Build and run the RESTORE ----
        $restoreSql = @"
USE [master];
IF DB_ID(N'$($Database.Name)') IS NOT NULL
BEGIN
    PRINT 'Forcing [$($Database.Name)] to SINGLE_USER to drop existing connections';
    ALTER DATABASE [$($Database.Name)] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
END;

RESTORE DATABASE [$($Database.Name)]
FROM DISK = N'$($BackupFile.Replace("'","''"))'
WITH FILE = 1,
     $moveClause,
     REPLACE,
     STATS = 5;

IF DB_ID(N'$($Database.Name)') IS NOT NULL
    ALTER DATABASE [$($Database.Name)] SET MULTI_USER;
"@

        Invoke-Sql -Server $ServerInstance -Query $restoreSql -QueryTimeout 0 | Out-Host

        # ---- 5. Verify ----
        $check = Invoke-Sql -Server $ServerInstance -Query "SELECT state_desc FROM sys.databases WHERE name = N'$($Database.Name)';"
        $state = ($check.state_desc | Select-Object -First 1)
        if ($state -eq 'ONLINE') {
            Write-Host "[$($Database.Name)] Successfully restored. State: ONLINE." -ForegroundColor Green
        } else {
            Write-Host "[$($Database.Name)] Restored but state is '$state'." -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "[$($Database.Name)] Restore failed." -ForegroundColor Red
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Check: SQL Server is running, your account has sysadmin rights, the .bak isn't blocked, and the default DATA folder exists." -ForegroundColor DarkYellow
    }
}

function Process-Selection {
    param($dbList, [int]$action)
    foreach ($entry in $dbList) {
        if ($action -in @(1,3)) { [void](Download-Database -Database $entry) }
        if ($action -in @(2,3)) { Install-Database -Database $entry }
    }
}

# =====================================================================
# Headless mode (parameters supplied) - skip menu
# =====================================================================
if ($DbChoice -ge 0 -and $ActionChoice -ge 1) {
    if ($DbChoice -eq 0) { return }
    if ($DbChoice -eq 4) {
        $selected = $Databases
    } else {
        $selected = $Databases | Where-Object { $_.ID -eq $DbChoice }
    }
    Process-Selection -dbList $selected -action $ActionChoice
    return
}

# =====================================================================
# Interactive menu
# =====================================================================
do {
    Clear-Host
    Write-Host "===============================================" -ForegroundColor Cyan
    Write-Host "   SQL Database Download & Install Manager"     -ForegroundColor Cyan
    Write-Host "   Script version: $ScriptVersion"              -ForegroundColor DarkGreen
    Write-Host "   Target folder : $BasePath"                   -ForegroundColor DarkGray
    Write-Host "   SQL instance  : $ServerInstance"             -ForegroundColor DarkGray
    Write-Host "===============================================" -ForegroundColor Cyan

    foreach ($db in $Databases) {
        Write-Host "$($db.ID). $($db.Name)"
    }
    Write-Host "4. ALL DATABASES"
    Write-Host "0. Exit"
    Write-Host "-----------------------------------------------"

    $picked = Read-Host "Select a database to process (0-4)"
    if ($picked -eq '0') { break }

    if ($picked -notmatch '^[1-4]$') {
        Write-Host "Invalid database selection." -ForegroundColor Red
        Pause; continue
    }

    Write-Host "`nActions:"
    Write-Host "1. Download Only"
    Write-Host "2. Install (Restore) Only"
    Write-Host "3. Both (Download and Install)"
    Write-Host "-----------------------------------------------"
    $action = Read-Host "Select an action (1-3)"

    if ($action -notmatch '^[1-3]$') {
        Write-Host "Invalid action selected." -ForegroundColor Red
        Pause; continue
    }

    if ($picked -eq '4') {
        $selected = $Databases
    } else {
        $selected = $Databases | Where-Object { $_.ID -eq [int]$picked }
    }

    Process-Selection -dbList $selected -action ([int]$action)

    Write-Host "`nOperation complete." -ForegroundColor Green
    Pause
} while ($true)
