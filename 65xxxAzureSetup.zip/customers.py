"""
customers.py
Generates customers.csv for 65316A Module 10 lab.

Output: customers.csv (unquoted, comma-delimited, CRLF, with header row)
Columns: CustomerID, FirstName, LastName, Email, Country, RegistrationDate

Usage:
    python customers.py
    python customers.py --count 10000 --output customers.csv --seed 42
"""

import csv
import random
import argparse
import datetime
from pathlib import Path

FIRST_NAMES = [
    "John", "Patricia", "Jennifer", "James", "Michael", "Linda", "Robert",
    "Barbara", "William", "Elizabeth", "David", "Susan", "Richard", "Jessica",
    "Joseph", "Sarah", "Thomas", "Karen", "Charles", "Lisa", "Christopher",
    "Nancy", "Daniel", "Betty", "Matthew", "Margaret", "Anthony", "Sandra",
    "Mark", "Ashley", "Donald", "Dorothy", "Steven", "Kimberly", "Paul",
    "Emily", "Andrew", "Donna", "Kenneth", "Michelle",
]

LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
    "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez",
    "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
    "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark",
    "Ramirez", "Lewis", "Robinson", "Walker", "Young", "Allen", "King",
    "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores",
]

COUNTRIES = [
    "USA", "France", "Japan", "Germany", "Australia",
    "Canada", "Brazil", "Mexico", "UK", "Spain",
]

START_DATE = datetime.date(2018, 1, 1)
END_DATE   = datetime.date(2024, 12, 31)
DATE_RANGE = (END_DATE - START_DATE).days


def generate_customers(count: int, seed: int) -> list:
    rng = random.Random(seed)
    rows = []
    for i in range(1, count + 1):
        fn  = rng.choice(FIRST_NAMES)
        ln  = rng.choice(LAST_NAMES)
        co  = rng.choice(COUNTRIES)
        reg = START_DATE + datetime.timedelta(days=rng.randint(0, DATE_RANGE))
        email = f"{fn.lower()}.{ln.lower()}{i}@example.com"
        rows.append([i, fn, ln, email, co, reg.strftime("%Y-%m-%d")])
    return rows


def main():
    parser = argparse.ArgumentParser(description="Generate customers.csv for 65316A Module 10")
    parser.add_argument("--count",  type=int,  default=10000,          help="Number of customer rows (default: 10000)")
    parser.add_argument("--output", type=str,  default="customers.csv", help="Output file path")
    parser.add_argument("--seed",   type=int,  default=42,             help="Random seed for reproducibility")
    args = parser.parse_args()

    output = Path(args.output)
    rows   = generate_customers(args.count, args.seed)

    # Write unquoted CSV with CRLF line endings
    # csv.QUOTE_NONE + no quotechar = fully unquoted output
    # newline='' lets csv module handle CRLF via lineterminator
    with open(output, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f,
                            quoting=csv.QUOTE_MINIMAL,
                            lineterminator="\r\n")
        writer.writerow(["CustomerID", "FirstName", "LastName",
                         "Email", "Country", "RegistrationDate"])
        writer.writerows(rows)

    print(f"Generated {args.count} rows -> {output}  ({output.stat().st_size:,} bytes)")
    # Show first 3 rows for verification
    with open(output, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i >= 4: break
            print(f"  {line}", end="")


if __name__ == "__main__":
    main()
